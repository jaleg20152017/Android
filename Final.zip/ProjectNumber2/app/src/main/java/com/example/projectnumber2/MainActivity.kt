package com.example.projectnumber2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPref.getBoolean("isLoggedIn", false)

        if (isLoggedIn) {
            // If logged in, go to EventListActivity
            startActivity(Intent(this, EventListActivity::class.java))
        } else {
            // If not logged in, go to LoginActivity
            startActivity(Intent(this, LoginActivity::class.java))
        }

        finish()
    }
}