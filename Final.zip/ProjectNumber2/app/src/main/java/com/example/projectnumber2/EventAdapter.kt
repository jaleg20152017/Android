package com.example.projectnumber2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.BaseAdapter

class EventAdapter(private val context: Context, private val events: List<Event>) : BaseAdapter() {

    override fun getCount(): Int = events.size

    override fun getItem(position: Int): Event = events[position]

    override fun getItemId(position: Int): Long = events[position].id.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_event, parent, false)
        val event = getItem(position)

        val tvEventName = view.findViewById<TextView>(R.id.tvEventName)
        val tvEventDate = view.findViewById<TextView>(R.id.tvEventDate)
        val tvEventLocation = view.findViewById<TextView>(R.id.tvEventLocation)

        tvEventName.text = event.name
        tvEventDate.text = event.date
        tvEventLocation.text = event.location

        return view
    }
}