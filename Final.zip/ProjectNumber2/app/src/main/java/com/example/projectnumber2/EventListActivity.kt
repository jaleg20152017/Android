package com.example.projectnumber2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EventListActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var eventAdapter: EventAdapter
    private lateinit var eventListView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_list)

        dbHelper = DatabaseHelper(this)
        eventListView = findViewById(R.id.eventListView)
        val btnAddEvent = findViewById<Button>(R.id.btnAddEvent)

        // Load events from database
        loadEvents()

        btnAddEvent.setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }

        eventListView.setOnItemLongClickListener { _, _, position, _ ->
            val event = eventAdapter.getItem(position)
            dbHelper.deleteEvent(event.id)
            loadEvents()
            Toast.makeText(this, "Event Deleted", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun loadEvents() {
        val events = dbHelper.getAllEvents()
        eventAdapter = EventAdapter(this, events)
        eventListView.adapter = eventAdapter
    }

    override fun onResume() {
        super.onResume()
        loadEvents()
    }
}