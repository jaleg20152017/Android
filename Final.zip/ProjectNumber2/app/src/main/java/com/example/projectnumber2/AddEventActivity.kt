package com.example.projectnumber2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddEventActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_event)

        val etEventName = findViewById<EditText>(R.id.etEventName)
        val etEventDate = findViewById<EditText>(R.id.etEventDate)
        val etEventLocation = findViewById<EditText>(R.id.etEventLocation)
        val btnSaveEvent = findViewById<Button>(R.id.btnSaveEvent)

        btnSaveEvent.setOnClickListener {
            val name = etEventName.text.toString()
            val date = etEventDate.text.toString()
            val location = etEventLocation.text.toString()

            if (name.isNotEmpty() && date.isNotEmpty() && location.isNotEmpty()) {
                // Save event to database
                val dbHelper = DatabaseHelper(this)
                if (dbHelper.insertEvent(name, date, location)) {
                    Toast.makeText(this, "Event saved!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Error saving event", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}