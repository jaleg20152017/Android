package com.example.projectnumber2

data class Event(val id: Int, val name: String, val date: String, val location: String)